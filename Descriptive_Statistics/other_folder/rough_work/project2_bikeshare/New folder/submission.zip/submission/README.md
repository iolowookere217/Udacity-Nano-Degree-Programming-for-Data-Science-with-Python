### Date created
December 23rd 2021


### Project Title
US BIKESHARE Data

### Description
in this project, we use python code to import US bike share data and answer interesting questions about it, by computing descriptive statistics. this project is a python script that takes in raw input to create an interactive experience in the terminal and present some statistics about the data.

### Files used
chicago.csv
new_york_city.csv
washington.csv

### Credits
google.com, stack overflow, udacity supporting materials

